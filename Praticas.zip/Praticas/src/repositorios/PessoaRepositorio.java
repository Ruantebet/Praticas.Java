package repositorios;

import java.util.AbstractList;
import java.util.List;

public class PessoaRepositorio {
    // Armazenará as pessoas cadastradas
    private static List<Pessoa> PESSOAS = new AbstractList<>();

    public Pessoa salvar(Pessoa pessoa) {
        PESSOAS.add(pessoa);
        return pessoa;
    }

    public void apagar(Pessoa pessoa) {
        PESSOAS.remove(pessoa);
    }

    public List<Pessoa> buscarTodasPessoas() {
        return PESSOAS;
    }
}
