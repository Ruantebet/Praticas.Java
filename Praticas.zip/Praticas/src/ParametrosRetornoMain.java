import modelos.Pessoa;
import servicos.PessoaServico;

import java.util.Date;

public class ParametrosRetornoMain {
    public static void main(String[] args) {
        parametrosRetornos();
    }

    public static void parametrosRetornos() {
        PessoaServico pessoaServico = new PessoaServico();

        Pessoa novaPessoa = new Pessoa();
        novaPessoa.setNome("Pessoa");
        novaPessoa.setSobrenome("Nova");
        novaPessoa.setDataNascimento(new Date());
        novaPessoa.setPais("Brasil");

        pessoaServico.salvar(novaPessoa);

        novaPessoa = new Pessoa();
        novaPessoa.setNome("Novíssima");
        novaPessoa.setSobrenome("Pessoa");
        novaPessoa.setDataNascimento(new Date());
        novaPessoa.setPais("Argentina");

        pessoaServico.salvar(novaPessoa);

        System.out.println(pessoaServico.buscarTodasPessoas());
    }

}