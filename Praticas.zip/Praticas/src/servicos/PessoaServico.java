package servicos;

import repositorios.PessoaRepositorio;

import java.util.List;

public class PessoaServico {

    private PessoaRepositorio repositorio = new PessoaRepositorio();

    public Pessoa salvar(Pessoa pessoa) {
        return repositorio.salvar(pessoa);
    }

    public List<Pessoa> buscarTodasPessoas() {
        return repositorio.buscarTodasPessoas();
    }
}
